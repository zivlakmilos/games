/*
    Class Player
        player.h
        player.cpp
*/

#include "main.h"
#include "player.h"

Player::Player(void)
{
    this->x = 0.0;
    this->y = 0.0;
    this->width = 84.0;
    this->height = 100.0;
    this->speed = 7.0;
    this->helth = 3.0;
    this->isAlive = true;
    this->name = "";
    this->moveState.down = false;
    this->moveState.right = false;
    this->moveState.up = false;
    this->moveState.left = false;
    this->angle = PLAYER_ANGLE_DOWN;
    this->textureState = 0;
    this->textureStateSide = 1;
}

Player::~Player(void)
{
    // Delete player
}

void Player::move(void)
{
    if(this->moveState.down)
    {
        this->y -= this->speed;
        this->angle = PLAYER_ANGLE_DOWN;
        if(this->textureState + this->textureStateSide == 2 || this->textureState == 0)
            this->textureStateSide = -this->textureStateSide;
    }
    else if(this->moveState.right)
    {
        this->x += this->speed;
        this->angle = PLAYER_ANGLE_RIGHT;
        if(this->textureState + this->textureStateSide == 2 || this->textureState ==0 )
            this->textureStateSide = -this->textureStateSide;
    }
    else if(this->moveState.up)
    {
        this->y += this->speed;
        this->angle = PLAYER_ANGLE_UP;
        if(this->textureState + this->textureStateSide == 2 || this->textureState == 0)
            this->textureStateSide = -this->textureStateSide;
    }
    else if(this->moveState.left)
    {
        this->x -= this->speed;
        this->angle = PLAYER_ANGLE_LEFT;
        if(this->textureState + this->textureStateSide == 2 || this->textureState == 0)
            this->textureStateSide = -this->textureStateSide;
    }
    else
    {
        this->textureState = 0;
    }
}

unsigned int Player::loadModel(SDL_Surface *image, SDL_Rect src, SDL_Rect dest)
{
    //SDL_Surface *image = IMG_Load(fileName);
    //SDL_DisplayFormatAlpha(image);
    SDL_Surface *destImage = NULL;
    SDL_DisplayFormatAlpha(destImage);
    unsigned object(0);
    glGenTextures(1, &object);
    glBindTexture(GL_TEXTURE_2D, object);

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    // Crop image for texture

    SDL_BlitSurface(image, &src, destImage, &dest);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, destImage->w, destImage->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, destImage->pixels);

    //SDL_FreeSurface(image); // Free surface
    SDL_FreeSurface(destImage);

    // Return texture
    return object;
}

void Player::loadTexture(void)
{
    SDL_Surface *image = IMG_Load("data/player.png");
    SDL_DisplayFormatAlpha(image);
    SDL_Rect src, dest;
    /*
    this->texture.d[0] = this->loadModel("data/Model 1.png", src, dest);
    this->texture.r[0] = this->loadModel("data/Model 2.png", src, dest);
    this->texture.u[0] = this->loadModel("data/Model 3.png", src, dest);
    this->texture.l[0] = this->loadModel("data/Model 4.png", src, dest);
    */
    src.x = 171;
    src.y = 231;
    src.w = 315;
    src.h = 408;
    this->texture.d[1] = this->loadModel(image, src, dest);
    SDL_FreeSurface(image); // Free surface
}

// Logic

void Player::changeMoveState(int type, int state)
{
    switch(type)
    {
        case PLAYER_MOVE_ADD:
            switch(state)
            {
                case PLAYER_MOVE_DOWN:
                    this->moveState.down = true;
                break;
                case PLAYER_MOVE_RIGHT:
                    this->moveState.right = true;
                break;
                case PLAYER_MOVE_UP:
                    this->moveState.up = true;
                break;
                case PLAYER_MOVE_LEFT:
                    this->moveState.left = true;
                break;
                default:
                    std::cout << "Player move state error\n";
                break;
            }
        break;
        case PLAYER_MOVE_DELETE:
            switch(state)
            {
                case PLAYER_MOVE_DOWN:
                    this->moveState.down = false;
                break;
                case PLAYER_MOVE_RIGHT:
                    this->moveState.right = false;
                break;
                case PLAYER_MOVE_UP:
                    this->moveState.up = false;
                break;
                case PLAYER_MOVE_LEFT:
                    this->moveState.left = false;
                break;
                default:
                    std::cout << "Player move state error\n";
                break;
            }
        break;
        default:
            std::cout << "Player move type error\n";
        break;
    }
}

// Render player
void Player::render(void)
{
    /*
    glColor4ub(0, 0, 0, 255);   // Black color
    glBegin(GL_QUADS);
        glVertex2f(this->x, this->y);
        glVertex2f(this->x + this->width, this->y);
        glVertex2f(this->x + this->width, this->y + this->height);
        glVertex2f(this->x, this->y + this->height);
    glEnd();
    */

    glColor4ub(255, 255, 255, 255); // White color
    glEnable(GL_TEXTURE_2D);
    
    switch(this->angle)
    {
        case PLAYER_ANGLE_DOWN:
            glBindTexture(GL_TEXTURE_2D, this->texture.d[textureState]);
        break;
        case PLAYER_ANGLE_RIGHT:
            glBindTexture(GL_TEXTURE_2D, this->texture.r[textureState]);
        break;
        case PLAYER_ANGLE_UP:
            glBindTexture(GL_TEXTURE_2D, this->texture.u[textureState]);
        break;
        case PLAYER_ANGLE_LEFT:
            glBindTexture(GL_TEXTURE_2D, this->texture.l[textureState]);
        break;
    }

    glBegin(GL_QUADS);
        glTexCoord2d(0, 1); glVertex2f(this->x, this->y);
        glTexCoord2d(1, 1); glVertex2f(this->x + this->width, this->y);
        glTexCoord2d(1, 0); glVertex2f(this->x + this->width, this->y + this->height);
        glTexCoord2d(0, 0); glVertex2f(this->x, this->y + this->height);
    glEnd();

    glDisable(GL_TEXTURE_2D);
}
