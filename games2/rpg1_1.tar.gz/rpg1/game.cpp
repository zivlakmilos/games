/*
    game.cpp
        code for game, main loop, window drawing, handle events
*/

// Include headers
#include "main.h"
#include "player.h"
#include "game.h"

Game::Game()
{
    this->x = 100;
    this->x = 100;
    this->width = 640;
    this->height = 480;
    this->caption = "";
    this->isRunning = true;
    this->fps = 0;
}

void Game::initialization(void)
{
    // SDL initialization
    SDL_Init(SDL_INIT_EVERYTHING);

    // Set OpenGL memory usage
    SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8);
    SDL_GL_SetAttribute(SDL_GL_BUFFER_SIZE, 32);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

    // Set window caption
    SDL_WM_SetCaption(this->caption, NULL);

    // Set size of window
    SDL_SetVideoMode(this->width, this->height, 32, SDL_OPENGL);

    // Set initialize clear color
    glClearColor(1, 1, 1, 1);

    // Part of screen to be display
    glViewport(0, this->height, this->width, 0);

    // Shade model
    glShadeModel(GL_SMOOTH);

    // Enable textures
    glEnable(GL_TEXTURE_2D);

    // 2D rendering
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Disable depth checking
    glDisable(GL_DEPTH_TEST);

    // Enable 2D texture
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Clear the window
    glClear(GL_COLOR_BUFFER_BIT);

    // Player initialization
    player.loadModel(); // Load texture

    // Load musics
}

// void for handle events
void Game::events(SDL_Event event)
{
    while(SDL_PollEvent(&event))
    {
        if(event.type == SDL_QUIT)
            this->isRunning = false;
        if(event.type == SDL_KEYUP && event.key.keysym.sym == SDLK_ESCAPE)
            this->isRunning = false;
    }
}

void Game::mainloop(void)
{
    // Initialization
    this->initialization();

    /*
        main loop
    */
    while(this->isRunning)
    {

        // EVENTS
        this->events(this->event);

        // LOGIC
        this->player.move();

        // RENDER
        glClear(GL_COLOR_BUFFER_BIT);
        this->player.render();

        // Swap buffers
        SDL_GL_SwapBuffers();
    }
}
