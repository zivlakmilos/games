/*
    player.cpp
        code for player, move, texture, helth
*/

// Include headers
#include "main.h"
#include "player.h"

// Player define constants
#define PLAYER_MOVE_ADD         0
#define PLAYER_MOVE_DELETE      1
#define PLAYER_MOVE_LEFT        3
#define PLAYER_MOVE_RIGHT       4
#define PLAYER_MOVE_UP          5
#define PLAYER_MOVE_DOWN        6

Player::Player(void)
{
    this->x = 0.0;
    this->y = 0.0;
    this->width = 10.0;
    this->height = 15.0;
    this->speed = 1.0;
    this->helth = 3.0;
    this->isAlive = true;
    this->name = "";
    /*
    for(i = 0; i < 3; i++)
    {
        this->textureName.l[i] = 0;
        this->textureName.r[i] = 0;
        this->textureName.u[i] = 0;
        this->texutreName.d[i] = 0;
    }
    */
    this->textureState = 0;
    this->left = false;
    this->right = false;
    this->up = false;
    this->down = false;
}

void Player::moveState(int type, int state)
{
    switch(type)
    {
        case PLAYER_MOVE_ADD:
            switch(state)
            {
                case PLAYER_MOVE_LEFT:
                    this->left = true;
                break;
                case PLAYER_MOVE_RIGHT:
                    this->right = true;
                break;
                case PLAYER_MOVE_UP:
                    this->up = true;
                break;
                case PLAYER_MOVE_DOWN:
                    this->down = true;
                break;
            }
        break;
        case PLAYER_MOVE_DELETE:
            switch(state)
            {
                case PLAYER_MOVE_LEFT:
                    this->left = false;
                break;
                case PLAYER_MOVE_RIGHT:
                    this->right = false;
                break;
                case PLAYER_MOVE_UP:
                    this->up = false;
                break;
                case PLAYER_MOVE_DOWN:
                    this->down = false;
                break;
            }
        break;
    }
}

void Player::move(void)
{
    if(left)
    {
        this->x -= this->speed;
    }
    else if(right)
    {
        this->x += this->speed;
    }
    else if(up)
    {
        this->y += this->speed;
    }
    else if(down)
    {
        this->x -= this->speed;
    }
}

void Player::loadModel()
{
    /*
    // Load image to memory
    this->model = SDL_DisplayFormat(SDL_LoadBMP("data/model.bmp"));

    // Source rectangle
    this->src.x = 0;
    this->src.y = 0;
    this->src.w = this->model->w;
    this->src.h = this->model->h;

    // Destination rectangle
    this->dest.x = 100;
    this->dest.y = 100;
    this->dest.w = this->model->w;
    this->dest.h = this->model->h;
    */

    // Load model
    model = IMG_Load("data/model.bmp");
    SDL_DisplayFormatAlpha(this->model);
    unsigned object(0);
    glGenTextures(1, &object);
    
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, this->model->w, this->model->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, this->model->pixels);

    SDL_FreeSurface(this->model);   // Free surface

    this->texture = object;

    // Copy texture

    // Set texture
}

void Player::render()
{
    glColor4ub(255, 255, 255, 255); // White color

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);

    glBegin(GL_QUADS);
        glTexCoord2d(0, 0); glVertex2f(this->x, this->y);
        glTexCoord2d(1, 0); glVertex2f(this->x + this->width, this->y);
        glTexCoord2d(1, 1); glVertex2f(this->x + this->width, this->y + this->height);
        glTexCoord2d(0, 1); glVertex2f(this->x, this->y + this->height);
    glEnd;

    glDisable(GL_TEXTURE_2D);
}
