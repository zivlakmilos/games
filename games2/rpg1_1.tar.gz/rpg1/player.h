#ifndef PLAYER_H
#define PLAYER_H

// Include headers
// #include "headers.h"

/*
struct PlayerTexture
{
    char *basic;
    int l[3];
    int r[3];
    int u[3];
    int d[3];
};
*/

class Player
{
// private:
private:
    float x;
    float y;
    float width;
    float height;
    float speed;
    float helth;
    bool isAlive;
    char *name;
    //PlayerTexture textureName;
    SDL_Surface *model;
    SDL_Surface *textureCrop;
    unsigned int texture;
    SDL_Rect src, dest;
    int textureState;
    bool left, right, up, down;

// public:
public:
    Player(void);
    void moveState(int type, int state);
    void move(void);
    void loadModel(void);
    void render();
};

#endif  // PLAYER_H
