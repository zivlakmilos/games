/*
    Class Player
        player.h
        player.cpp
*/

#include "main.h"
#include "player.h"

Player::Player(void)
{
    this->x = 0.0;
    this->y = 0.0;
    this->width = 84.0;
    this->height = 100.0;
    this->speed = 10.0;
    this->helth = 3.0;
    this->isAlive = true;
    this->name = "";
    this->moveState.down = false;
    this->moveState.right = false;
    this->moveState.up = false;
    this->moveState.left = false;
}

Player::~Player(void)
{
    // Delete player
}

void Player::move(void)
{
    if(this->moveState.down)
    {
        this->y -= this->speed;
    }
    else if(this->moveState.right)
    {
        this->x += this->speed;
    }
    else if(this->moveState.up)
    {
        this->y += this->speed;
    }
    else if(this->moveState.left)
    {
        this->x -= this->speed;
    }
}

void Player::changeMoveState(int type, int state)
{
    switch(type)
    {
        case PLAYER_MOVE_ADD:
            switch(state)
            {
                case PLAYER_MOVE_DOWN:
                    this->moveState.down = true;
                break;
                case PLAYER_MOVE_RIGHT:
                    this->moveState.right = true;
                break;
                case PLAYER_MOVE_UP:
                    this->moveState.up = true;
                break;
                case PLAYER_MOVE_LEFT:
                    this->moveState.left = true;
                break;
            }
        break;
        case PLAYER_MOVE_DELETE:
            switch(state)
            {
                case PLAYER_MOVE_DOWN:
                    this->moveState.down = false;
                break;
                case PLAYER_MOVE_RIGHT:
                    this->moveState.right = false;
                break;
                case PLAYER_MOVE_UP:
                    this->moveState.up = false;
                break;
                case PLAYER_MOVE_LEFT:
                    this->moveState.left = false;
                break;
            }
        break;
    }
}

// Render player
void Player::render(void)
{
    glColor4ub(0, 0, 0, 255);   // Black color
    glBegin(GL_QUADS);
        glVertex2f(this->x, this->y);
        glVertex2f(this->x + this->width, this->y);
        glVertex2f(this->x + this->width, this->y + this->height);
        glVertex2f(this->x, this->y + this->height);
    glEnd();
}
